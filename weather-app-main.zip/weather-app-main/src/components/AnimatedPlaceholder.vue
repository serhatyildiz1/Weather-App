<template>
  <div class="animate-pulse bg-gradient-to-r from-gray-100 ">
    &nbsp;
  </div>
</template>
